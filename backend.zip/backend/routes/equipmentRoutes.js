const express = require("express");
const fs = require("fs");
const { v4: uuid } = require("uuid");
const router = express.Router();

const filePath = "./data/equipment.json";

// Helper function
const readData = () =>
  JSON.parse(fs.readFileSync(filePath));

// GET all equipment
router.get("/", (req, res) => {
  res.json(readData());
});

// ADD equipment
router.post("/", (req, res) => {
  const data = readData();
  const newItem = { id: uuid(), ...req.body };
  data.push(newItem);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  res.status(201).json(newItem);
});

// UPDATE equipment
router.put("/:id", (req, res) => {
  let data = readData();
  data = data.map(item =>
    item.id === req.params.id ? { ...item, ...req.body } : item
  );
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  res.json({ message: "Updated successfully" });
});

// DELETE equipment
router.delete("/:id", (req, res) => {
  const data = readData().filter(item => item.id !== req.params.id);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  res.json({ message: "Deleted successfully" });
});

module.exports = router;
