# Equipment Tracker

A simple full-stack web application built as part of an Intern Take-Home Assignment to manage equipment records.

---

## 🚀 How to Run the Project Locally

### Prerequisites
- Node.js
- npm
- Git

---

### Backend Setup
```bash
cd backend
npm install
node server.js
