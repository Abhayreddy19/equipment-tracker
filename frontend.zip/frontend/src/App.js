import { useEffect, useState } from "react";
import EquipmentForm from "./components/EquipmentForm";
import EquipmentTable from "./components/EquipmentTable";
import "./App.css";

const API = "http://localhost:5000/api/equipment";

function App() {
  const [equipment, setEquipment] = useState([]);
  const [editItem, setEditItem] = useState(null);

  const loadData = async () => {
    const res = await fetch(API);
    setEquipment(await res.json());
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <div className="container">
      <h2>Equipment Tracker</h2>
      <EquipmentForm
        API={API}
        loadData={loadData}
        editItem={editItem}
        setEditItem={setEditItem}
      />
      <EquipmentTable
        data={equipment}
        API={API}
        loadData={loadData}
        setEditItem={setEditItem}
      />
    </div>
  );
}

export default App;
