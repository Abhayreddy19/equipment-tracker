import { useEffect, useState } from "react";

const emptyForm = {
  name: "",
  type: "",
  status: "",
  lastCleaned: ""
};

export default function EquipmentForm({ API, loadData, editItem, setEditItem }) {
  const [form, setForm] = useState(emptyForm);

  useEffect(() => {
    if (editItem) setForm(editItem);
  }, [editItem]);

  const handleSubmit = async e => {
    e.preventDefault();

    if (!form.name || !form.type || !form.status || !form.lastCleaned) {
      alert("All fields are required");
      return;
    }

    const method = editItem ? "PUT" : "POST";
    const url = editItem ? `${API}/${editItem.id}` : API;

    await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });

    setForm(emptyForm);
    setEditItem(null);
    loadData();
  };

  return (
    <form onSubmit={handleSubmit}>
      <input placeholder="Name"
        value={form.name}
        onChange={e => setForm({ ...form, name: e.target.value })}
      />

      <select value={form.type}
        onChange={e => setForm({ ...form, type: e.target.value })}>
        <option value="">Type</option>
        <option>Machine</option>
        <option>Vessel</option>
        <option>Tank</option>
        <option>Mixer</option>
      </select>

      <select value={form.status}
        onChange={e => setForm({ ...form, status: e.target.value })}>
        <option value="">Status</option>
        <option>Active</option>
        <option>Inactive</option>
        <option>Under Maintenance</option>
      </select>

      <input type="date"
        value={form.lastCleaned}
        onChange={e => setForm({ ...form, lastCleaned: e.target.value })}
      />

      <button>{editItem ? "Update" : "Add"}</button>
    </form>
  );
}
